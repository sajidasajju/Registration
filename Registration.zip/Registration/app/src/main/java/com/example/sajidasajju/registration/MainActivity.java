package com.example.sajidasajju.registration;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText et1,et2;
    String user_name,user_password;
    SharedPreferences sharedPreferences;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        et1=findViewById(R.id.editname);
        et2=findViewById(R.id.editpassword);
        sharedPreferences=getSharedPreferences(RegisterActivity.PREFERENCES,MODE_PRIVATE);
    }

    public void login(View view)
    {
        user_name=et1.getText().toString();
        user_password=et2.getText().toString();
        if(user_name.equals(sharedPreferences.getString(RegisterActivity.NAME_KEY,"ssss"))
                &&user_password.equals(sharedPreferences.getString(RegisterActivity.PASSWORD,"sssssw")))
        {
           Intent i =new Intent(this,Login.class);
           startActivity(i);
        }

    }
  

    public void register(View view)
    {
          if (sharedPreferences==null)
          {
              Intent intent=new Intent(this,RegisterActivity.class);
              startActivity(intent);
          }
        else
          {
              Toast.makeText(this, "you have already registered", Toast.LENGTH_SHORT).show();
          }


    }

    public void logout(View view) {
        SharedPreferences.Editor editor=sharedPreferences.edit();
        editor.clear();
    }
}
