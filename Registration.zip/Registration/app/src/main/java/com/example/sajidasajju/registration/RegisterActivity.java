package com.example.sajidasajju.registration;

import android.content.Context;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.util.prefs.Preferences;

public class RegisterActivity extends AppCompatActivity {
    public static final String PREFERENCES= "SRIT";
    public static final String NAME_KEY="namekey";
    public static final  String PASSWORD="passwordkey";
    SharedPreferences sharedPreferences;
    EditText name_id,name_password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        name_id=findViewById(R.id.userid);
        name_password=findViewById(R.id.password);
        sharedPreferences=getSharedPreferences(PREFERENCES, Context.MODE_PRIVATE);


    }

    public void register(View view) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        if (name_id.getText().toString() != null && name_password.getText().toString() != null) {
            editor.putString("namekey", name_id.getText().toString());
            editor.putString("passwordkey", name_password.getText().toString());
            editor.apply();
            finish();

        } else
            Toast.makeText(this, "enter valid username and password", Toast.LENGTH_SHORT).show();
    }
}
